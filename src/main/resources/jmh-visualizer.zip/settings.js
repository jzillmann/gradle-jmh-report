var defaultSettings = { // eslint-disable-line no-unused-vars
    topBar: 'default' //possible values ['default', 'off', 'my custom headline']
}