var settings = { // eslint-disable-line no-unused-vars
    showHeader: true
}